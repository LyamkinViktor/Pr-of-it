<?php

return [ 1 => 'town.jpg', 2 => 'sea.jpg', 3 => 'ship.jpg'];