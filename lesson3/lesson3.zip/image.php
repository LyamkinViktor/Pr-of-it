<?php

$id = $_GET ['id'];

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Галерея</title>
    <style>
        .big{
            width: 800px;
            height: 500px;
        }
    </style>
</head>
    <body>
        <img class="big" src="/lesson3/<?php echo $id; ?>">
    </body>
</html>
