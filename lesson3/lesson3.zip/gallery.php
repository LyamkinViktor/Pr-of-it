<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Галерея</title>
    <style>
        .image{
            width: 350px;
            height: 200px;
        }
    </style>
</head>
<body>

<?php

$pictures = ['1.jpg', '2.jpg', '3.jpg'];

?>

<?php foreach ($pictures as $pic) { ?>
<a href="/lesson3/image.php?id=<?php echo $pic; ?>">
    <img class="image" src="/lesson3/<?php echo $pic; ?>">
</a>
<?php } ?>



</body>
</html>