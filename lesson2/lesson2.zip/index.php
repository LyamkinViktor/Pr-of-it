<?php include __DIR__ . '/functions.php'?>
<!doctype html>
<html lang="en">
<head>
    <title>Lesson 2</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<h1>Задание 1</h1>
<h2>Таблица истинности</h2>

<p>
    <table>
        <tr>
            <th class="column1">&&</th>
            <th>0</th>
            <th>1</th>
        </tr>
        <tr>
            <th>0</th>
            <td><?php echo (int) (0 && 0);?></td>
            <td><?php echo (int) (0 && 1);?></td>
        </tr>
        <tr>
            <th>1</th>
            <td><?php echo (int) (1 && 0);?></td>
            <td><?php echo (int) (1 && 1);?></td>
        </tr>
    </table>

</p>

<p>
    <table>
        <tr>
            <th class="column1">||</th>
            <th>0</th>
            <th>1</th>
        </tr>
        <tr>
            <th>0</th>
            <td><?php echo (int) (0 || 0);?></td>
            <td><?php echo (int) (0 || 1);?></td>
        </tr>
        <tr>
            <th>1</th>
            <td><?php echo (int) (1 || 0);?></td>
            <td><?php echo (int) (1 || 1);?></td>
        </tr>
    </table>

</p>

<p>
    <table>
        <tr>
            <th class="column1">xor</th>
            <th>0</th>
            <th>1</th>
        </tr>
        <tr>
            <th>0</th>
            <td><?php echo (int) (0 xor 0);?></td>
            <td><?php echo (int) (0 xor 1);?></td>
        </tr>
        <tr>
            <th>1</th>
            <td><?php echo (int) (1 xor 0);?></td>
            <td><?php echo (int) (1 xor 1);?></td>
        </tr>
    </table>

</p>

<hr>

<h1>Задание 2</h1>

<h2>Решение дискриминанта:</h2>

<h3>Введите значения для формулы ax<sup><small>2</small></sup> + bx + c = 0</h3>

<p>
    <form action="index.php" method="post">
        <label> a <input class="form" type="text" name="a" value="<?php echo $_POST ['a']?>"> </label>
        <label> b <input class="form" type="text" name="b" value="<?php echo $_POST ['b']?>"> </label>
        <label> c <input class="form" type="text" name="c" value="<?php echo $_POST ['c']?>"> </label><br><br>
        <input type="submit" value="Решить">
    </form>
</p>
<p>
    Ответ: D =  <?php echo discriminant($_POST ['a'], $_POST ['b'], $_POST ['c']) ?>
</p>

<hr>

<h1>Задание 3</h1>

<p>
    include включает файл и выполняет его, к примеру, если в файл test.php записать функцию, которая высчитывает сумму
    двух чисел то результат работы этой функции будет доступен на странице включения:<br>
    <?php
    include __DIR__ . '/test.php';
    echo $total;
    ?>
</p>
<p>
    include можно записать в переменную - в  таком случае переменная будет содержать значение файла test1:<br>
    <?php
    $c = include __DIR__ . '/test1.php';
    var_dump($c);
    ?>
</p>
<p>
    В случае, если файл будет включен внутри функции включающего файла, то весь код включаемого файла будет
    виден только внутри этой функции, за исключением магических констант:<br>
    <?php

    function foo()
    {
        include __DIR__ . '/test2.php';
        return $a;
    }

    echo foo(); // Результат работы функции - значение переменной $a, включенной в функцию

    ?>

<hr>
<h1>Задание 4</h1>

<?php function gender($name)
{
    $a = substr($name, strlen($name) -2);

    if ($a  == 'а' || $a == 'я') {
    return 'женский пол';
    }   elseif ($a == 'р' || $a == 'й' || $a == 'л' || $a == 'с'){
    return 'мужской пол';
    }
    else {
    return null;
    }
}

assert( gender('Виктор') == 'мужской пол');
assert( gender('Елена') == 'женский пол');
assert( gender('Тигран') == null);

echo gender( 'Елена');

?>

</p>



</body>
</html>