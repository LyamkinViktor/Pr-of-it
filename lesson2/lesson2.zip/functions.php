<?php

$a = $_POST ['a'];
$b = $_POST ['b'];
$c = $_POST ['c'];


function discriminant ($a, $b, $c)
{
    $d = ($b ** 2) - (4 * $a * $c);
    return $d;
}
assert( discriminant(6, -13, 2) == 121 );
assert( discriminant(4, 36, 81) == 0 );
assert( discriminant(9, -7, 10) == -311 );

/* Решение корней:
    if  ($d > 0) {
        $x1 = ((-$b) + sqrt($d)) / (2 * $a);
        $x2 = ((-$b) - sqrt($d)) / (2 * $a);
        return 'x1,2 = ' . round($x1,2) . '; ' . round($x2,2);
    } elseif ( $d == 0 ) {
        $x = -($b / (2 * $a));
        return 'x = ' . round($x, 2);
    } else {
        return 'Нет корней!';
    }
}
*/