<?php

return 12345;