<?php

$a = 5;
$b = 15;

function sum($a, $b)
{
    return $a + $b;
}

$total = sum($a, $b);