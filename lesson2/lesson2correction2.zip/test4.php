<?php


return 10 + 15;